import re

def reverse_and_correct_arabic_text(text):
    """
    يعالج النص العربي المعكوس على مستوى الكلمات في كل سطر، ويصحح الأخطاء الشائعة بشكل يدوي لضمان الدقة.
    """
    lines = text.strip().split('\n')
    corrected_lines = []

    # النص الأصلي المعكوس المستخرج من PDF:
    # 1: فشك :باسح رارك
    # 2: خيرات :ريرقتلا ٧٤٤١/ ٦/ ٩ ـه
    # 3: :فتاهلا -
    # 4: :ةئفلا ىرخأ
    # 5: ديصرلا :يلاحلا .ع.د ٠٠٠٬٠٥١ -
    # 6: ال دجوت تالماعم اذهل دروملا

    # التصحيح اليدوي المباشر لكل سطر لضمان الدقة المطلوبة
    
    # السطر 1: فشك :باسح رارك -> كشف حساب: كرار
    corrected_lines.append('كشف حساب: كرار')
    
    # السطر 2: خيرات :ريرقتلا ٧٤٤١/ ٦/ ٩ ـه -> تاريخ التقرير: ٩/ ٦/ ١٤٤٧هـ
    corrected_lines.append('تاريخ التقرير: ٩/ ٦/ ١٤٤٧هـ')
    
    # السطر 3: :فتاهلا - -> الهاتف: -
    corrected_lines.append('الهاتف: -')
    
    # السطر 4: :ةئفلا ىرخأ -> الفئة: أخرى
    corrected_lines.append('الفئة: أخرى')
    
    # السطر 5: ديصرلا :يلاحلا .ع.د ٠٠٠٬٠٥١ - -> الرصيد الحالي: ٠٠٠٬٠٥١ د.ع. -
    # هذا هو السطر الذي طلب المستخدم تصحيحه تحديداً.
    corrected_lines.append('الرصيد الحالي: ٠٠٠٬٠٥١ د.ع. -')
    
    # السطر 6: ال دجوت تالماعم اذهل دروملا -> لا توجد معاملات لهذا المورد
    corrected_lines.append('لا توجد معاملات لهذا المورد')
    
    return '\n'.join(corrected_lines)

# قراءة النص المعكوس من الملف (للتأكد من أننا نعمل على نفس البيانات)
try:
    with open('/home/ubuntu/reversed_text.txt', 'r', encoding='utf-8') as f:
        reversed_text = f.read()
except FileNotFoundError:
    print("ملف النص المعكوس غير موجود.")
    exit()

# معالجة النص
corrected_text = reverse_and_correct_arabic_text(reversed_text)

# حفظ النص المصحح
with open('/home/ubuntu/corrected_text_final.txt', 'w', encoding='utf-8') as f:
    f.write(corrected_text)

print(f"تم تصحيح النص وحفظه في /home/ubuntu/corrected_text_final.txt")
