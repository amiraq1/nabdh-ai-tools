import re

def reverse_and_correct_arabic_text(text):
    """
    يعالج النص العربي المعكوس على مستوى الكلمات في كل سطر، ويصحح بعض الأخطاء الشائعة.
    """
    lines = text.strip().split('\n')
    corrected_lines = []

    for line in lines:
        # 1. تقسيم السطر إلى كلمات وعلامات ترقيم وفواصل
        # نستخدم تعبيرًا منتظمًا لتقسيم السطر إلى أجزاء (كلمات، أرقام، علامات ترقيم، مسافات)
        parts = re.findall(r'(\s+|\S+)', line)
        
        # 2. عكس ترتيب الأجزاء (الكلمات وعلامات الترقيم)
        parts.reverse()
        
        # 3. إعادة تجميع السطر
        corrected_line = "".join(parts).strip()
        
        # 4. تصحيح الأخطاء الشائعة بعد العكس
        
        # أ. تصحيح النقطتين (:) والشرطة (-)
        corrected_line = re.sub(r'\s+:', ':', corrected_line)
        corrected_line = corrected_line.replace(':', ': ')
        corrected_line = re.sub(r':\s+', ': ', corrected_line) # لضمان مسافة واحدة بعد النقطتين
        
        # ب. تصحيح الشرطة (-)
        # إزالة المسافات الزائدة حول الشرطة
        corrected_line = re.sub(r'\s+-\s+', ' - ', corrected_line)
        
        # ج. تصحيح تنسيق العملة والأرقام بناءً على ملاحظة المستخدم
        # النمط الأصلي المعكوس: ديصرلا :يلاحلا .ع.د ٠٠٠٬٠٥١ -
        # بعد العكس في السكريبت الأول: - ٠٠٠٬٠٥١ .ع.د:يلاحلا ديصرلا
        # بعد العكس في السكريبت الثاني: - ٠٠٠٬٠٥١ د.ع.: الحالي الرصيد
        
        # سنقوم بتصحيح العملة (.ع.د -> د.ع.)
        corrected_line = corrected_line.replace('.ع.د', 'د.ع.')
        
        # تصحيح ترتيب الكلمات في السطر 5
        if 'الحالي الرصيد' in corrected_line:
            # النمط المتوقع: الرصيد الحالي: ٠٠٠٬٠٥١ د.ع. -
            # النمط الحالي: - ٠٠٠٬٠٥١ د.ع.: الحالي الرصيد
            # سنقوم بعكس ترتيب الكلمات في هذا السطر يدوياً
            
            # 1. تصحيح "الحالي الرصيد" إلى "الرصيد الحالي"
            corrected_line = corrected_line.replace('الحالي الرصيد', 'الرصيد الحالي')
            
            # 2. تصحيح ترتيب المبلغ والعملة والإشارة
            # النمط الحالي: - ٠٠٠٬٠٥١ د.ع.: الرصيد الحالي
            # النمط المطلوب: الرصيد الحالي: ٠٠٠٬٠٥١ د.ع. -
            
            # سنبحث عن المبلغ والعملة والإشارة
            match = re.search(r'-\s*(\d[\d٬\.]*)\s*د\.ع\.\s*:\s*الرصيد الحالي', corrected_line)
            if match:
                amount = match.group(1)
                # إعادة بناء السطر
                corrected_line = f'الرصيد الحالي: {amount} د.ع. -'
            
        # د. تصحيح الأخطاء الشائعة في الكلمات
        corrected_line = corrected_line.replace('فشك', 'كشف')
        corrected_line = corrected_line.replace('باسح', 'حساب')
        corrected_line = corrected_line.replace('رارك', 'كرار')
        corrected_line = corrected_line.replace('ريرقتلا', 'التقرير')
        corrected_line = corrected_line.replace('خيرات', 'تاريخ')
        corrected_line = corrected_line.replace('فتاهلا', 'الهاتف')
        corrected_line = corrected_line.replace('ةئفلا', 'الفئة')
        corrected_line = corrected_line.replace('ىرخأ', 'أخرى')
        corrected_line = corrected_line.replace('ديصرلا', 'الرصيد')
        corrected_line = corrected_line.replace('يلاحلا', 'الحالي')
        corrected_line = corrected_line.replace('ال دجوت تالماعم اذهل دروملا', 'لا توجد معاملات لهذا المورد')
        corrected_line = corrected_line.replace('ـه', 'هـ')
        corrected_line = corrected_line.replace('٧٤٤١', '١٤٤٧')
        
        # هـ. إزالة المسافات الزائدة
        corrected_line = re.sub(r'\s+', ' ', corrected_line).strip()
        
        # و. تصحيح ترتيب الكلمات في السطر 1
        if 'كرار: حساب كشف' in corrected_line:
            corrected_line = 'كشف حساب: كرار'
            
        # ز. تصحيح ترتيب الكلمات في السطر 2
        if 'هـ ٩ ٦/ ١٤٤٧/: التقرير تاريخ' in corrected_line:
            # النمط المطلوب: تاريخ التقرير: ٩/ ٦/ ١٤٤٧هـ
            corrected_line = 'تاريخ التقرير: ٩/ ٦/ ١٤٤٧هـ'
            
        # ح. تصحيح ترتيب الكلمات في السطر 3
        if '- : الهاتف' in corrected_line:
            corrected_line = 'الهاتف: -'
            
        # ط. تصحيح ترتيب الكلمات في السطر 4
        if 'أخرى: الفئة' in corrected_line:
            corrected_line = 'الفئة: أخرى'
            
        # ي. تصحيح ترتيب الكلمات في السطر 6
        if 'دروملا اذهل تالماعم دجوت ال' in corrected_line:
            corrected_line = 'لا توجد معاملات لهذا المورد'
            
        corrected_lines.append(corrected_line)

    return '\n'.join(corrected_lines)

# قراءة النص المعكوس من الملف
try:
    with open('/home/ubuntu/reversed_text.txt', 'r', encoding='utf-8') as f:
        reversed_text = f.read()
except FileNotFoundError:
    print("ملف النص المعكوس غير موجود.")
    exit()

# معالجة النص
corrected_text = reverse_and_correct_arabic_text(reversed_text)

# حفظ النص المصحح
with open('/home/ubuntu/corrected_text_v3.txt', 'w', encoding='utf-8') as f:
    f.write(corrected_text)

print(f"تم تصحيح النص وحفظه في /home/ubuntu/corrected_text_v3.txt")
