import re

def reverse_and_correct_arabic_text(text):
    """
    يعالج النص العربي المعكوس على مستوى الكلمات في كل سطر، ويصحح بعض الأخطاء الشائعة.
    """
    lines = text.strip().split('\n')
    corrected_lines = []

    for line in lines:
        # 1. تقسيم السطر إلى كلمات وعلامات ترقيم وفواصل
        # نستخدم تعبيرًا منتظمًا لتقسيم السطر إلى أجزاء (كلمات، أرقام، علامات ترقيم، مسافات)
        parts = re.findall(r'(\s+|\S+)', line)
        
        # 2. عكس ترتيب الأجزاء (الكلمات وعلامات الترقيم)
        # هذا هو جوهر مشكلة الانعكاس في PDF
        parts.reverse()
        
        # 3. إعادة تجميع السطر
        corrected_line = "".join(parts).strip()
        
        # 4. تصحيح الأخطاء الشائعة بعد العكس
        
        # أ. تصحيح النقطتين (:) والشرطة (-)
        # النقطتان يجب أن تتبع الكلمة التي تصفها (مثل "حساب:")
        # الشرطة (-) يجب أن تكون قبل أو بعد المبلغ حسب التنسيق
        
        # تصحيح النقطتين: إزالة المسافة قبلها وإضافة مسافة بعدها
        corrected_line = re.sub(r'\s+:', ':', corrected_line)
        corrected_line = corrected_line.replace(':', ': ')
        
        # تصحيح الشرطة: إزالة المسافة قبلها وإضافة مسافة بعدها
        corrected_line = re.sub(r'\s+-', '-', corrected_line)
        corrected_line = corrected_line.replace('-', ' - ')
        
        # تصحيح الأقواس (إذا وجدت)
        corrected_line = corrected_line.replace('( ', '(').replace(' )', ')')
        
        # تصحيح تنسيق العملة والأرقام بناءً على ملاحظة المستخدم
        # البحث عن نمط: [علامة] [مبلغ] [عملة]
        # مثال: - ٠٠٠٬٠٥١ .ع.د
        # يجب أن يصبح: ٠٠٠٬٠٥١ د.ع. -
        
        # سنقوم بتصحيح العملة (.ع.د -> د.ع.)
        corrected_line = corrected_line.replace('.ع.د', 'د.ع.')
        
        # سنقوم بتصحيح ترتيب المبلغ والعملة والإشارة يدوياً في هذه الحالة
        # نبحث عن نمط "د.ع. - [مبلغ]" ونعكسه
        match = re.search(r'(\d[\d٬\.]*)\s*د\.ع\.\s*-\s*', corrected_line)
        if match:
            amount = match.group(1)
            # النمط المعكوس هو: - ٠٠٠٬٠٥١ د.ع.
            # النمط الصحيح هو: ٠٠٠٬٠٥١ د.ع. -
            # سنقوم باستبدال النمط المعكوس بالنمط الصحيح
            reversed_pattern = f'- {amount} د.ع.'
            correct_pattern = f'{amount} د.ع. -'
            corrected_line = corrected_line.replace(reversed_pattern, correct_pattern)
            
        # تصحيح التاريخ: ٧٤٤١/ ٦/ ٩ ـه -> ٩/ ٦/ ١٤٤٧هـ
        # النمط المعكوس هو: ٧٤٤١/ ٦/ ٩ ـه
        # النمط الصحيح هو: ٩/ ٦/ ١٤٤٧هـ
        # سنقوم بتصحيح الأرقام المعكوسة (٧٤٤١ -> ١٤٤٧)
        corrected_line = corrected_line.replace('٧٤٤١', '١٤٤٧')
        corrected_line = corrected_line.replace('ـه', 'هـ')
        
        # تصحيح "فشك" و "باسح" و "رارك"
        corrected_line = corrected_line.replace('فشك', 'كشف')
        corrected_line = corrected_line.replace('باسح', 'حساب')
        corrected_line = corrected_line.replace('رارك', 'كرار')
        
        # تصحيح "ريرقتلا" و "خيرات"
        corrected_line = corrected_line.replace('ريرقتلا', 'التقرير')
        corrected_line = corrected_line.replace('خيرات', 'تاريخ')
        
        # تصحيح "فتاهلا"
        corrected_line = corrected_line.replace('فتاهلا', 'الهاتف')
        
        # تصحيح "ةئفلا" و "ىرخأ"
        corrected_line = corrected_line.replace('ةئفلا', 'الفئة')
        corrected_line = corrected_line.replace('ىرخأ', 'أخرى')
        
        # تصحيح "ديصرلا" و "يلاحلا"
        corrected_line = corrected_line.replace('ديصرلا', 'الرصيد')
        corrected_line = corrected_line.replace('يلاحلا', 'الحالي')
        
        # تصحيح "ال دجوت تالماعم اذهل دروملا"
        corrected_line = corrected_line.replace('ال دجوت تالماعم اذهل دروملا', 'لا توجد معاملات لهذا المورد')
        
        # إزالة المسافات الزائدة
        corrected_line = re.sub(r'\s+', ' ', corrected_line).strip()
        
        corrected_lines.append(corrected_line)

    return '\n'.join(corrected_lines)

# قراءة النص المعكوس من الملف
try:
    with open('/home/ubuntu/reversed_text.txt', 'r', encoding='utf-8') as f:
        reversed_text = f.read()
except FileNotFoundError:
    print("ملف النص المعكوس غير موجود.")
    exit()

# معالجة النص
corrected_text = reverse_and_correct_arabic_text(reversed_text)

# حفظ النص المصحح
with open('/home/ubuntu/corrected_text_v2.txt', 'w', encoding='utf-8') as f:
    f.write(corrected_text)

print(f"تم تصحيح النص وحفظه في /home/ubuntu/corrected_text_v2.txt")
