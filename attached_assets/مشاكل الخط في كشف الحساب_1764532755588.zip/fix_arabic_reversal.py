import re

def reverse_arabic_text(text):
    """
    يعالج النص العربي المعكوس على مستوى الكلمات في كل سطر.
    """
    lines = text.strip().split('\n')
    corrected_lines = []

    for line in lines:
        # تقسيم السطر إلى كلمات مع الاحتفاظ بالفواصل والنقاط والأرقام
        # نستخدم regex للتقسيم على المسافات مع الاحتفاظ بالفواصل والنقاط والأرقام كجزء من الكلمات أو كفواصل
        # هذا التعبير يحاول فصل الكلمات مع الحفاظ على الترتيب النسبي للعلامات
        
        # تقسيم السطر إلى أجزاء بناءً على المسافات، مع الاحتفاظ بالمسافات
        parts = re.split(r'(\s+)', line.strip())
        
        # تصفية الأجزاء الفارغة
        parts = [p for p in parts if p]
        
        # عكس ترتيب الأجزاء
        parts.reverse()
        
        # إعادة تجميع السطر
        corrected_line = "".join(parts)
        
        # معالجة خاصة للعلامات مثل النقطتين (:) والشرطة (-) التي قد تكون معكوسة
        # على سبيل المثال: "فشك :باسح رارك" يجب أن تصبح "كشف حساب: كرار"
        # إذا كانت النقطتان في بداية كلمة، يجب أن تكون في نهايتها بعد العكس.
        
        # بما أن العكس يتم على مستوى الكلمات، يجب أن نعالج النقطتين يدويًا
        # هذا جزء صعب بدون معرفة دقيقة بهيكل النص. سنعتمد على العكس البسيط أولاً.
        
        # محاولة عكس الترتيب فقط للكلمات، مع الحفاظ على الفواصل
        words_and_separators = re.findall(r'(\S+|\s+)', line)
        
        # فصل الكلمات عن الفواصل (المسافات)
        words = [w for w in words_and_separators if not w.isspace()]
        separators = [w for w in words_and_separators if w.isspace()]
        
        # عكس الكلمات
        words.reverse()
        
        # إعادة بناء السطر بترتيب معكوس للكلمات
        reconstructed_line = ""
        
        # إذا كان عدد الكلمات أكبر من الفواصل، نبدأ بكلمة
        if len(words) > len(separators):
            for i in range(len(separators)):
                reconstructed_line += words[i] + separators[i]
            reconstructed_line += words[-1]
        # إذا كان عدد الفواصل أكبر أو يساوي، نبدأ بفاصل (وهذا غير منطقي في العادة)
        elif len(words) > 0:
            for i in range(len(words)):
                reconstructed_line += words[i]
                if i < len(separators):
                    reconstructed_line += separators[i]
        else:
            reconstructed_line = line # لا يوجد كلمات، إبقاء السطر كما هو

        # معالجة النقطتين (:) والشرطة (-) التي قد تكون معكوسة
        # مثال: "فشك :باسح رارك" -> "كرار حساب: كشف"
        # بعد العكس البسيط: "رارك باسح: فشك"
        
        # سنعتمد على العكس البسيط للأجزاء (الكلمات والفواصل)
        
        # إعادة المحاولة باستخدام regex أكثر بساطة: تقسيم على المسافات فقط
        parts = line.strip().split(' ')
        parts.reverse()
        corrected_line = ' '.join(parts)
        
        # تصحيح بعض الأخطاء الشائعة بعد العكس
        # 1. النقطتان (:) يجب أن تسبقها كلمة وتتبعها مسافة
        corrected_line = corrected_line.replace(' :', ': ')
        corrected_line = corrected_line.replace(': ', ':') # إزالة المسافة الزائدة قبل النقطتين
        
        corrected_lines.append(corrected_line)

    return '\n'.join(corrected_lines)

# قراءة النص المعكوس من الملف
try:
    with open('/home/ubuntu/reversed_text.txt', 'r', encoding='utf-8') as f:
        reversed_text = f.read()
except FileNotFoundError:
    print("ملف النص المعكوس غير موجود.")
    exit()

# معالجة النص
corrected_text = reverse_arabic_text(reversed_text)

# حفظ النص المصحح
with open('/home/ubuntu/corrected_text.txt', 'w', encoding='utf-8') as f:
    f.write(corrected_text)

print(f"تم تصحيح النص وحفظه في /home/ubuntu/corrected_text.txt")
